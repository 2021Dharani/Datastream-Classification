# Import EntroPy objects
from .utils import *
from .entropy import *
from .fractal import *

__version__ = "0.1.2"
