from mailbox import Error
import findspark
import sklearn
import time
findspark.init('C:\opt\spark\spark-2.4.7-bin-hadoop2.7')
from pyspark.sql import SparkSession
# from pyspark.sql.functions import col
import pandas as pd
import re
from pyspark.sql.types import IntegerType, StringType, StructType, StructField
from collections import OrderedDict
# spark = SparkSession.builder.appName("LogMining").master("local").config("spark.executor.cores","6").config("spark.executor.memory","2g").getOrCreate()
from pyspark.sql import Row
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import f1_score
from numpy import *
from sklearn.model_selection import train_test_split
from pyspark.ml import Pipeline
from pyspark.ml.classification import DecisionTreeClassifier
from pyspark.ml.feature import StringIndexer, VectorIndexer
from pyspark.ml.evaluation import MulticlassClassificationEvaluator
from pyspark.mllib.util import MLUtils
from pyspark.mllib.tree import DecisionTree, DecisionTreeModel
import hashlib
import pandas as pd
import os
import numpy as np
import re
import sys
from collections import Counter
from scipy.special import expit
from itertools import compress
from neuron import *
from sklearn.metrics import confusion_matrix
from sklearn.metrics import matthews_corrcoef
from sklearn.svm import SVC
import runstats
from runstats import Statistics
from entropy import *
from scipy.stats import chisquare
import scipy.stats as stats1
def parse_hdfs_log_line(logline,APACHE_ACCESS_LOG_PATTERN):
    match = re.findall(APACHE_ACCESS_LOG_PATTERN, logline)
    if match is None:
        raise Error("Invalid logline: %s" % logline)
    return Row(
        Date = match[0][0],
        Time = match[0][1],
        Pid = match[0][2],
        Level = match[0][3],
        Component = match[0][4],
        Content = match[0][5])

def parse_hdfs_file(file,APACHE_ACCESS_LOG_PATTERN):
    ab = []
    file_line = file.readlines()
    for line in range(len(file_line)):
        match = re.findall(APACHE_ACCESS_LOG_PATTERN, file_line[line])
        for mat in range(len(match)):
            bd = re.sub("[\d.-]+", "<*>", match[mat][5])
            eventid = hashlib.md5(' '.join(bd).encode('utf-8')).hexdigest()[:]#[1:8]
            ab.append(Row(Date =  match[mat][0],Time = match[mat][1],Pid =match[mat][2],Level =  match[mat][3],Component   = match[mat][4],Content  = match[mat][5], EventTemplate=bd, EventId =eventid ))
    return ab
def read_file(data):
    # struct_log = spark.read.format("csv").option("header", "true").load(file)
    data_dict = OrderedDict()
    for rowe in data.collect():
        blkId_list = re.findall(r'(blk_-?\d+)', rowe['Content'])
        blkId_set = set(blkId_list)
        for blk_Id in blkId_set:
            if not blk_Id in data_dict:
                data_dict[blk_Id] = []
            data_dict[blk_Id].append(rowe['EventId'])
    data_df = spark.createDataFrame(list(data_dict.items()), schema=['BlockId', 'EventSequence'])

    return data_df

class FeatureExtractor(object):

    def __init__(self):
        self.idf_vec = None
        self.mean_vec = None
        self.events = None
        self.term_weighting = None
        self.normalization = None
        self.oov = None

    def fit_transform(self, X_seq, term_weighting=None, normalization=None, oov=False, min_count=1):
        print('====== Transformed train data summary ======')
        self.term_weighting = term_weighting
        self.normalization = normalization
        self.oov = oov

        X_counts = []
        for i in range(X_seq.shape[0]):
            event_counts = Counter(X_seq[i])
            X_counts.append(event_counts)
        X_df = pd.DataFrame(X_counts)
        X_df = X_df.fillna(0)
        self.events = X_df.columns
        X = X_df.values
        if self.oov:
            oov_vec = np.zeros(X.shape[0])
            if min_count > 1:
                idx = np.sum(X > 0, axis=0) >= min_count
                oov_vec = np.sum(X[:, ~idx] > 0, axis=1)
                X = X[:, idx]
                self.events = np.array(X_df.columns)[idx].tolist()
            X = np.hstack([X, oov_vec.reshape(X.shape[0], 1)])

        num_instance, num_event = X.shape
        if self.term_weighting == 'tf-idf':
            df_vec = np.sum(X > 0, axis=0)
            self.idf_vec = np.log(num_instance / (df_vec + 1e-8))
            idf_matrix = X * np.tile(self.idf_vec, (num_instance, 1))
            X = idf_matrix
        if self.normalization == 'zero-mean':
            mean_vec = X.mean(axis=0)
            self.mean_vec = mean_vec.reshape(1, num_event)
            X = X - np.tile(self.mean_vec, (num_instance, 1))
        elif self.normalization == 'sigmoid':
            X[X != 0] = expit(X[X != 0])
        X_new = X

        print('Train data shape: {}-by-{}\n'.format(X_new.shape[0], X_new.shape[1]))
        return X_new

    def transform(self, X_seq):
        print('====== Transformed test data summary ======')
        X_counts = []
        for i in range(X_seq.shape[0]):
            event_counts = Counter(X_seq[i])
            X_counts.append(event_counts)
        X_df = pd.DataFrame(X_counts)
        X_df = X_df.fillna(0)
        empty_events = set(self.events) - set(X_df.columns)
        for event in empty_events:
            X_df[event] = [0] * len(X_df)
        X = X_df[self.events].values
        if self.oov:
            oov_vec = np.sum(X_df[X_df.columns.difference(self.events)].values > 0, axis=1)
            X = np.hstack([X, oov_vec.reshape(X.shape[0], 1)])

        num_instance, num_event = X.shape
        if self.term_weighting == 'tf-idf':
            idf_matrix = X * np.tile(self.idf_vec, (num_instance, 1))
            X = idf_matrix
        if self.normalization == 'zero-mean':
            X = X - np.tile(self.mean_vec, (num_instance, 1))
        elif self.normalization == 'sigmoid':
            X[X != 0] = expit(X[X != 0])
        X_new = X

        print('Test data shape: {}-by-{}\n'.format(X_new.shape[0], X_new.shape[1]))

        return X_new
def DBN_Classifier(x_train, y_train,x_test,y_test):
    from dbn.tensorflow import SupervisedDBNClassification
    classifier = SupervisedDBNClassification(hidden_layers_structure=[64, 64], learning_rate_rbm=0.005,
                                             learning_rate=0.01, n_epochs_rbm=5,
                                             n_iter_backprop=10, batch_size=128, activation_function='sigmoid',
                                             dropout_p=0.02)
    classifier.fit(x_train, y_train)
    # # Save the model
    # classifier.save('model.pkl')
    # # Restore it
    # classifier = SupervisedDBNClassification.load('model.pkl')
    # Test
    Y_pred = classifier.predict(x_test)
    # print("test accuracy: ", f1_score(y_test, Y_pred, average='micro'))
    return Y_pred
def KNN_Classifier(x_train, y_train,x_test,y_test):
    from sklearn.neighbors import KNeighborsClassifier
    model = KNeighborsClassifier(n_neighbors=2)
    # Train the model using the training sets
    model.fit(x_train, y_train)
    # Predict Output
    predicted = model.predict(x_test)
    # print("test accuracy: ", f1_score(y_test, predicted, average='micro'))
    #
    # print(predicted)
    return predicted
def DT_Classifier(x_train, y_train,x_test,y_test):
    from sklearn.tree import DecisionTreeClassifier
    model = DecisionTreeClassifier()
    # Train the model using the training sets
    model.fit(x_train, y_train)
    # Predict Output
    predicted = model.predict(x_test)
    # print("test accuracy: ", f1_score(y_test, predicted, average='micro'))
    #
    # print(predicted)
    return predicted
def NN_Classifier(x_train, y_train,x_test,y_test):
    net = Network(x_train.shape[1], 2, [4, 1], dropout=1)
    y_train = np.reshape(y_train, (-1, 1))
    y_test = np.reshape(y_test, (-1, 1))

    net.trainOptimized(x_train, y_train, x_test, y_test)
    y_pred_3 = net.predict(x_test)
    th = (y_pred_3.max() - y_pred_3.min()) / 2.5
    y_pred_3[y_pred_3 <= th] = 0
    y_pred_3[y_pred_3 != 0] = 1
    print("test accuracy: ", f1_score(y_test, y_pred_3, average='micro'))
    return y_pred_3
def train_and_evaluate_NN(X_train, Y_train, X_test, Y_test):
    # Create a model
    model = sklearn.neural_network.MLPClassifier(hidden_layer_sizes=(100,), activation='relu', solver='adam',
                                                 alpha=0.0001, batch_size='auto', learning_rate='constant',
                                                 learning_rate_init=0.001, power_t=0.5,
                                                 max_iter=500, shuffle=True, random_state=None, tol=0.0001,
                                                 verbose=False, warm_start=False, momentum=0.9,
                                                 nesterovs_momentum=True, early_stopping=False, validation_fraction=0.1,
                                                 beta_1=0.9, beta_2=0.999, epsilon=1e-08,
                                                 n_iter_no_change=10)

    # Train the model on the whole data set
    model.fit(X_train, Y_train)
    # Evaluate on test data
    predictions = model.predict(X_test)
    return predictions
from numpy.random import uniform, randint, choice, normal
def perf_evalution_CM(y, y_pred):
            T1 =y_pred
            TN, FN, FP, TP = confusion_matrix(np.asarray(y), np.asarray(T1)).ravel()
            SEN = (TP) / (TP + FN)
            SPE = (TN) / (TN + FP)
            ACC = (TP + TN) / (TP + TN + FP + FN)
            FMS = (2 * TP) / (2 * TP + FP + FN)
            PRE = (TP) / (TP + FP)
            REC = SEN
            TS = (TP) / (TP + FP + FN)  # Threat score
            NPV = (TN) / (TN + FN)  # negative predictive value
            FOR = (FN) / (FN + TN)  # false omission rate
            MCC = matthews_corrcoef(y, T1)  # Matthews correlation coefficient
            return [ACC, SEN, SPE, PRE, REC, FMS, TS, NPV, FOR, MCC]
def Local_classifier_train_test(data_train, label_train, data_test):
    clf = SVC(gamma='auto', kernel='rbf')
    clf.fit(data_train, label_train)
    pred_2 = clf.predict(data_test)
    return pred_2
def Main_Data_Feature_Extraction_All(fname):
    fo = open(fname, "r")
    APACHE_ACCESS_LOG_PATTERN = '^(\S+) (\S+) (\S+) (\S+) (\S+) (.*)'
    logline = "081109 203518 35 INFO dfs.FSNamesystem: BLOCK* NameSystem.allocateBlock: /mnt/hadoop/mapred/system/job_200811092030_0001/job.jar. blk_-1608999687919862906"
    match = re.findall(APACHE_ACCESS_LOG_PATTERN, logline)
    abc = parse_hdfs_log_line(logline,APACHE_ACCESS_LOG_PATTERN)
    s = "BLOCK* NameSystem.addStoredBlock: blockMap updated: 10.251.73.220:50010 is added to blk_7128370237687728475 size 67108864"
    s = re.sub("[\d.-]+", "<*>", s)

    parsed_file = parse_hdfs_file(fo,APACHE_ACCESS_LOG_PATTERN)
    customSchema = StructType([
        StructField("Date", StringType(), True),
        StructField("Time", StringType(), True),
        StructField("Pid", StringType(), True),
        StructField("Level", StringType(), True),
        StructField("Component", StringType(), True),
        StructField("Content", StringType(), True),
        StructField("EventTemplate", StringType(), True),
        StructField("EventId", StringType(), True)
    ])
    # '<Date> <Time> <Level> \[<Process>\] <Component>: <Content>
    # customSchema = StructType([
    #     StructField("Date", StringType(), True),
    #     StructField("Time", StringType(), True),
    #     StructField("Level", StringType(), True),
    #     StructField("Process", StringType(), True),
    #     StructField("Component", StringType(), True),
    #     StructField("Content", StringType(), True),
    # ])
    df_train = spark.createDataFrame(parsed_file, schema=customSchema)
    # df_train.show(5)
    df_train.toPandas()['Content'].unique()

    df_train_append = read_file(df_train)
    label_csv = spark.read.format("csv").option("header", "true").load("anomaly_label.csv")
    label_data = label_csv.toPandas().set_index('BlockId')
    label_dict = label_data['Label'].to_dict()

    df_train_append_pd = df_train_append.toPandas()
    df_train_append_pd['Label'] = df_train_append_pd['BlockId'].apply(lambda x: 1 if label_dict[x] == 'Anomaly' else 0)
    df_event = spark.createDataFrame(df_train_append_pd)

    Feat = df_train_append_pd['EventSequence'].values
    Lab = df_train_append_pd['Label'].values
    feature_extractor = FeatureExtractor()
    Feat = feature_extractor.fit_transform(Feat, term_weighting='tf-idf')
    Feat_1=[]
    for tq in range(0,Feat.shape[0]):
        Feat_1.append(main_feat_ext_all(Feat[tq,:]).reshape(1,-1))
    Feat_11=np.asarray(Feat_1).reshape(len(Feat_1),Feat_1[0].shape[1])
    Feat=np.hstack((Feat,Feat_11))
    Feat = Feat / Feat.max()
    Sel_Feat_1=Main_FS_OPT_Final(Feat, 25, 1)
    Sel_Feat_2=Main_FS_OPT_Final(Feat, 25, 2)
    Sel_Feat_3=Main_FS_OPT_Final(Feat, 25, 3)
    Feat_0=Feat[:,Sel_Feat_1]
    Feat_1=Feat[:,Sel_Feat_2]
    Feat_2=Feat[:,Sel_Feat_3]

    index = np.where(Lab == 1)
    index_1 = index[0]
    index = np.where(Lab == 0)
    index_0 = index[0]
    return [index_0,index_1,Feat,Feat_0,Feat_1,Feat_2,df_event,Lab]
def main_train_data_split(Feat,index_0,index_1,tot_lab_1,tot_lab_0):
    x_train = np.concatenate((Feat[index_1[:tot_lab_1], :], Feat[index_0[:tot_lab_0], :]))
    x_test = np.concatenate((Feat[index_1[tot_lab_1:], :], Feat[index_0[tot_lab_0:], :]))
    return x_train,x_test
def Perf_Evaluation_save_all_final(index_0,index_1,Feat,Feat_0,Feat_1,Feat_2,df_event,Lab,tt):
    tr_per = 0.4
    # perf_A = []
    # perf_B = []
    # perf_C = []
    # perf_D = []
    # perf_E = []
    # perf_F = []
    # perf_G = []
    perf_H = []
    for a in range(5):
        tot_lab_1 = np.round(len(index_1) * tr_per).astype(int)
        tot_lab_0 = np.round(len(index_0) * tr_per).astype(int)
        x_train,x_test=main_train_data_split(Feat, index_0, index_1, tot_lab_1, tot_lab_0)
        x_train_0,x_test_0=main_train_data_split(Feat_0, index_0, index_1, tot_lab_1, tot_lab_0)
        x_train_1,x_test_1=main_train_data_split(Feat_1, index_0, index_1, tot_lab_1, tot_lab_0)
        x_train_2,x_test_2=main_train_data_split(Feat_2, index_0, index_1, tot_lab_1, tot_lab_0)
        y_train = np.concatenate((Lab[index_1[:tot_lab_1],], Lab[index_0[:tot_lab_0],]))
        y_test = np.concatenate((Lab[index_1[tot_lab_1:],], Lab[index_0[tot_lab_0:],]))
        # start_time = time.time()
        # y_pred_1 = KNN_Classifier(x_train, y_train,x_test,y_test)
        # TT1=(time.time() - start_time)
        # start_time = time.time()
        # y_pred_2 = NN_Classifier(x_train, y_train, x_test, y_test)
        # TT2=(time.time() - start_time)
        # start_time = time.time()
        # y_pred_3 = DT_Classifier(x_train, y_train,x_test,y_test)
        # TT3=(time.time() - start_time)
        # start_time = time.time()
        # y_pred_4 = Local_classifier_train_test(x_train, y_train, x_test)
        # TT4=(time.time() - start_time)
        # start_time = time.time()
        # y_pred_5 = DBN_Classifier(x_train, y_train,x_test,y_test)
        # TT5=(time.time() - start_time)
        # start_time = time.time()
        # y_pred_6 = DBN_Classifier(x_train_0, y_train,x_test_0,y_test)
        # TT6=(time.time() - start_time)
        # start_time = time.time()
        # y_pred_7 = DBN_Classifier(x_train_1, y_train,x_test_1,y_test)
        # TT7=(time.time() - start_time)
        start_time = time.time()
        y_pred_8 = DBN_Classifier(x_train_2, y_train,x_test_2,y_test)
        TT8=(time.time() - start_time)

        # [ACC1, SEN1, SPE1, PRE1, REC1, FMS1, TS1, NPV1, FOR1, MCC1] = perf_evalution_CM(y_test, y_pred_1)
        # [ACC2, SEN2, SPE2, PRE2, REC2, FMS2, TS2, NPV2, FOR2, MCC2] = perf_evalution_CM(y_test, y_pred_2)
        # [ACC3, SEN3, SPE3, PRE3, REC3, FMS3, TS3, NPV3, FOR3, MCC3] = perf_evalution_CM(y_test, y_pred_3)
        # [ACC4, SEN4, SPE4, PRE4, REC4, FMS4, TS4, NPV4, FOR4, MCC4] = perf_evalution_CM(y_test, y_pred_4)
        # [ACC5, SEN5, SPE5, PRE5, REC5, FMS5, TS5, NPV5, FOR5, MCC5] = perf_evalution_CM(y_test, y_pred_5)
        # [ACC6, SEN6, SPE6, PRE6, REC6, FMS6, TS6, NPV6, FOR6, MCC6] = perf_evalution_CM(y_test, y_pred_6)
        # [ACC7, SEN7, SPE7, PRE7, REC7, FMS7, TS7, NPV7, FOR7, MCC7] = perf_evalution_CM(y_test, y_pred_7)
        [ACC8, SEN8, SPE8, PRE8, REC8, FMS8, TS8, NPV8, FOR8, MCC8] = perf_evalution_CM(y_test, y_pred_8)

        # perf_1 = [ACC1, SEN1, SPE1, PRE1, REC1, FMS1, TS1, NPV1, FOR1, MCC1,TT1]
        # perf_2 = [ACC2, SEN2, SPE2, PRE2, REC2, FMS2, TS2, NPV2, FOR2, MCC2,TT2]
        # perf_3 = [ACC3, SEN3, SPE3, PRE3, REC3, FMS3, TS3, NPV3, FOR3, MCC3,TT3]
        # perf_4 = [ACC4, SEN4, SPE4, PRE4, REC4, FMS4, TS4, NPV4, FOR4, MCC4,TT4]
        # perf_5 = [ACC5, SEN5, SPE5, PRE5, REC5, FMS5, TS5, NPV5, FOR5, MCC5,TT5]
        # perf_6 = [ACC6, SEN6, SPE6, PRE6, REC6, FMS6, TS6, NPV6, FOR6, MCC6,TT6]
        # perf_7 = [ACC7, SEN7, SPE7, PRE7, REC7, FMS7, TS7, NPV7, FOR7, MCC7,TT7]
        perf_8 = [ACC8, SEN8, SPE8, PRE8, REC8, FMS8, TS8, NPV8, FOR8, MCC8,TT8]

        # perf_A.append(perf_1)
        # perf_B.append(perf_2)
        # perf_C.append(perf_3)
        # perf_D.append(perf_4)
        # perf_E.append(perf_5)
        # perf_F.append(perf_6)
        # perf_G.append(perf_7)
        perf_H.append(perf_8)
        tr_per = tr_per + 0.1
    print(perf_H)

def entropy(data, bins=100):
    hist = np.histogramdd(data, bins=bins)[0]
    prob = hist/len(data)
    prob[prob == 0] = 1
    log_prob = np.log2(prob)
    return -np.sum(np.multiply(prob, log_prob))
def gini(x):
    # Mean absolute difference
    mad = np.abs(np.subtract.outer(x, x)).mean()
    # Relative mean absolute difference
    rmad = mad/np.mean(x)
    # Gini coefficient
    g = 0.5 * rmad
    return g
def holo_entropy(data, bins=100):
    hist = np.histogramdd(data, bins=bins)[0]
    prob = hist/len(data)
    prob[prob == 0] = 1
    log_prob = np.log2(prob)
    ent=-np.sum(np.multiply(prob, log_prob))
    weight=2*(1-(1/(1+np.exp(-1*ent))))
    hent=ent*weight
    return hent
import pandas as pd
import numpy as np

def ewma(x, alpha):
    # Coerce x to an array
    x = np.array(x)
    n = x.size
    # Create an initial weight matrix of (1-alpha), and a matrix of powers
    # to raise the weights by
    w0 = np.ones(shape=(n,n)) * (1-alpha)
    p = np.vstack([np.arange(i,i-n,-1) for i in range(n)])
    # Create the weight matrix
    w = np.tril(w0**p,0)
    # Calculate the ewma
    return np.dot(w, x[::np.newaxis]) / w.sum(axis=1)
def gain(d):
    total =sum(d) /(sum(d) * entropy(d))
    gain = entropy(d) - total
    return gain
def main_feat_ext_all(sel_feat):
    En = holo_entropy(sel_feat, bins=100)
    # QW = ewma(x=sel_feat, alpha=0.55)
    # QW = QW.mean()
    stats = Statistics(sel_feat)
    f11=gini(sel_feat)
    # oddsratio, pvalue = stats1.fisher_exact(sel_feat)
    f0= chisquare(sel_feat)
    f12=gain(sel_feat)
    f1 = stats.mean()
    f2 = stats.variance()
    f3 = stats.skewness()
    f4 = stats.kurtosis()
    f5 = perm_entropy(sel_feat, order=3, normalize=True)  # Permutation entropy
    f6 = spectral_entropy(sel_feat, 100, method='welch', normalize=True)  # Spectral entropy
    f7 = svd_entropy(sel_feat, order=3, delay=1, normalize=True)  # Singular value decomposition entropy
    f8 = app_entropy(sel_feat, order=2, metric='chebyshev')  # Approximate entropy
    f9 = sample_entropy(sel_feat, order=2, metric='chebyshev')  # Sample entropy
    feat=np.nan_to_num(np.asarray([En,f11,f0.statistic,f0.pvalue,f12,f1,f2,f3,f4,f5,f6,f7,f8,f9]))
    return feat
from opfunu.cec_basic.cec2014_nobias import *
import BSO
import SARO
import SARO_MOD
def Main_FS_OPT_Final(Feat,sel_feat,opt):
    ## Setting parameters
    obj_func = F1
    lb = [-100]
    ub = [100]
    problem_size = sel_feat
    batch_size = 50
    verbose = True
    epoch = 100
    pop_size = 25
    OD=Feat.shape[1]
    if opt==1:
        md1 = BSO.BaseBSO(obj_func, lb, ub, problem_size, batch_size, verbose, epoch, pop_size, m=5, p1=0.2, p2=0.8,
                          p3=0.4, p4=0.5, k=20, miu=0, xichma=1, OD=OD)
    elif opt==2:
        md1 = SARO.BaseSARO(obj_func, lb, ub, problem_size=100, batch_size=10, verbose=True, epoch=50, pop_size=25,
                            se=0.5, mu=50, OD=OD)
    else:
        md1 = SARO_MOD.BaseSARO_MOD(obj_func, lb, ub, problem_size=100, batch_size=10, verbose=True,epoch=50, pop_size=25, se=0.5, mu=50,OD=OD)
    best_pos1, best_fit1, list_loss1,sel_feat = md1.train()
    return sel_feat
